#!C:\Users\Prafu\AppData\Local\Programs\Python\Python39\python
import pymysql
import cgi
print("Content-type: text/html")
print()

print("<link rel='stylesheet' href='bootstrap.min.css'>")

req=cgi.FieldStorage()
nm=req.getvalue("cnm")
modnm=req.getvalue("modnm")
con=pymysql.connect(host='localhost',user='root',password='@JINKYA@1234',database='carsdb')
curs=con.cursor()
try:
  curs.execute("select * from carinfo where companynm='%s' AND  modelnm='%s'" %(nm,modnm))
  data=curs.fetchall()

  print("<div class='container'>")
  print("<br><br>")
  print('<h2>Search Cars</h2><hr>')
  print("<a href='AdminHome.html'>Home</a><br><br>")
#print(data)

  for rec in data:
        
     print("<br>Number           :",rec[0])
     print("<br>Car Company Name :",rec[1])
     print("<br>Car Type         :",rec[2])
     print("<br>Fuel Type        :",rec[3])
     print("<br>Price         : ", rec[4])

     con.close()
except:
    print("error")     



