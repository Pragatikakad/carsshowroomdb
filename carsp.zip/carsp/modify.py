#!C:\Users\Prafu\AppData\Local\Programs\Python\Python39\python
import cgi
import pymysql

print("Content-type: text/html")
print()

req=cgi.FieldStorage()
cmpnm=req.getvalue("cmpnm")
modnm=req.getvalue("modno")
amt=int(req.getvalue("amt"))

con=pymysql.connect(host='localhost',user='root',password='@JINKYA@1234',database='carsdb')
curs=con.cursor()

try:
    curs.execute("call replace_price(%d,'%s','%s')" %(amt,cmpnm,modnm))
    con.commit()
    
    print('price updated successfully')
except:
    print('failed')


con.close()
print("<br><br><a href='AdminHome.html'>Home</a>")
