#!C:\Users\Prafu\AppData\Local\Programs\Python\Python39\python
import pymysql

print("Content-type: text/html")
print()

print("<link rel='stylesheet' href='bootstrap.min.css'>")

con=pymysql.connect(host='localhost',user='root',password='@JINKYA@1234',database='carsdb')
curs=con.cursor()

curs.execute("select * from customer")
data=curs.fetchall()

print("<div class='container'>")
print("<br><br>")
print('<h2>All Customer List</h2><hr>')
print("<a href='AdminHome.html'>Home</a><br><br>")
#print(data)

print("<table class='table table-bordered table-hover'>")
print("<tr style='background-color:azure'>")
print("<th>Number")
print("<th>Name")
print("<th>Type")
print("<th>")
print("</tr>")

for rec in data:
    print("<tr>")
    print("<td>",rec[0])
    print("<td>",rec[1])
    print("<td>",rec[2])
    print("<td>",rec[3])
    print("</tr>")

print("</table>")

con.close()



