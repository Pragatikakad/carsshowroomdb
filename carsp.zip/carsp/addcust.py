#!C:\Users\Prafu\AppData\Local\Programs\Python\Python39\python
import cgi
import pymysql

print("Content-type: text/html")
print()

req=cgi.FieldStorage()
custid=req.getvalue("cid")
nm=req.getvalue("cnm")
mo=req.getvalue("mono")
add=req.getvalue("add")


con=pymysql.connect(host='localhost',user='root',password='@JINKYA@1234',database='carsdb')
curs=con.cursor()

try:
    curs.execute("insert into customer values('%s','%s','%s','%s')" %(custid,nm,mo,add))
    con.commit()
    print('<h3>Customer Registered successfully</h3>')
except:
    print('<h3>Registration failed</h3>')

con.close()
