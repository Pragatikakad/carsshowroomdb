#!C:\Users\Prafu\AppData\Local\Programs\Python\Python39\python
import cgi
import pymysql

print("Content-type: text/html")
print()

req=cgi.FieldStorage()

carnm=req.getvalue("cnm")
model=req.getvalue("modnm")
type=req.getvalue("type")
fuel=req.getvalue("Fuel")
price=req.getvalue("price")
engine=req.getvalue("engine")
wheel=req.getvalue("wheel")

con=pymysql.connect(host='localhost',user='root',password='@JINKYA@1234',database='carsdb')
curs=con.cursor()

try:
    curs.execute("insert into carinfo(companynm,modelnm,car_type,fuel_type,price,eng_capacity,no_of_wheels) values('%s','%s','%s','%s','%s','%s','%s')" %(carnm,model,type,fuel,price,engine,wheel))
    con.commit()
    print('<h3>Car Registered successfully</h3>')
except:
    print('<h3>Registration failed</h3>')

con.close()
