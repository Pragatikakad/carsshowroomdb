#!C:\Users\Prafu\AppData\Local\Programs\Python\Python39\python
import cgi
import pymysql

print("Content-type: text/html")
print()

req=cgi.FieldStorage()
nm=req.getvalue("comp")

con=pymysql.connect(host='localhost',user='root',password='@JINKYA@1234',database='carsdb')
curs=con.cursor()

curs.execute("select * from carinfo where car_type='%s'" %nm)
data=curs.fetchall()

print("<table class='table table-bordered table-hover'>")

for rec in data:
    print("<tr>")
    print("<td>",rec[0])
    print("<td>",rec[1])
    print("<td>",rec[2])
    print("<td>",rec[3])
    print("<td>",rec[4])
    print("<td>",rec[5])
    print("<td>",rec[6])
    print("<td>",rec[7])
    print("</tr>")

print("<table>")

con.close()