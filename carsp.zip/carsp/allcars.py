#!C:\Users\Prafu\AppData\Local\Programs\Python\Python39\python
import pymysql

print("Content-type: text/html")
print()

print("<link rel='stylesheet' href='bootstrap.min.css'>")

con=pymysql.connect(host='localhost',user='root',password='@JINKYA@1234',database='carsdb')
curs=con.cursor()

curs.execute("select * from carinfo")
data=curs.fetchall()

print("<div class='container'>")
print("<br><br>")
print('<h2>All Cars Report </h2><hr>')
print("<a href='AdminHome.html'>Home</a><br><br>")
#print(data)

print("<table class='table table-bordered table-hover'>")
print("<tr style='background-color:azure'>")
print("<th>Id ")
print("<th>Company Name")
print("<th>Model Name")
print("<th>Car Type")
print("<th>Fuel Type")
print("<th>Price")
print("<th>Engine Capacity")
print("<th>No Of Wheels")

print("</tr>")

for rec in data:
    print("<tr>")
    print("<td>",rec[0])
    print("<td>",rec[1])
    print("<td>",rec[2])
    print("<td>",rec[3])
    print("<td>",rec[4])
    print("<td>",rec[5])
    print("<td>",rec[6])
    print("<td>",rec[7])

    print("</tr>")

print("</table>")

con.close()



