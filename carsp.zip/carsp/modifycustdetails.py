#!C:\Users\Prafu\AppData\Local\Programs\Python\Python39\python
import cgi
import pymysql

print("Content-type: text/html")
print()

req=cgi.FieldStorage()
nm=req.getvalue("custnm")
mob=req.getvalue("mono")

try:

    con=pymysql.connect(host='localhost',user='root',password='@JINKYA@1234',database='carsdb')
    curs=con.cursor()

    curs.execute("update customer set mobile = '%s' where name = '%s'" %(mob,nm))
    con.commit()
    
    print(' updated successfully')
except:
    print('failed')


con.close()
print("<br><br><a href='AdminHome.html'>Home</a>")
