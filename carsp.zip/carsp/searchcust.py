#!C:\Users\Prafu\AppData\Local\Programs\Python\Python39\python
import pymysql
import cgi
print("Content-type: text/html")
print()

print("<link rel='stylesheet' href='bootstrap.min.css'>")

req=cgi.FieldStorage()
nm=req.getvalue("cnm")
modnm=req.getvalue("modnm")
con=pymysql.connect(host='localhost',user='root',password='@JINKYA@1234',database='carsdb')
curs=con.cursor()

curs.execute("select * from customer where name='%s'" %(nm))
data=curs.fetchall()

print("<div class='container'>")
print("<br><br>")
print('<h2>Customer Details</h2><hr>')
print("<a href='AdminHome.html'>Home</a><br><br>")
#print(data)

for rec in data:
   
    print("<br>Id ",rec[0])
    
    print("<br>Name ",rec[1])
    print("<br>Mobile",rec[2])
    print("<br>Address: ", rec[3])
    

con.close()



